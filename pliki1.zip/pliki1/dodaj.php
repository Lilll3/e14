<?php
   $servername = "localhost";
   $username = "root";
   $database = "dane";
   $password = "";
   $conn = mysqli_connect($servername, $username, $password, $database);

$tytul = $_POST["tytul"];
$gatunek = $_POST["gatunek"];
$rok = $_POST["rok"];
$ocena = $_POST["ocena"];  


$add = mysqli_query($conn, "INSERT INTO `filmy`(`id`, `gatunki_id`, `rezyserzy_id`, `tytul`, `rok`, `ocena`) VALUES ('','$gatunek','','$tytul','$rok','$ocena')");


echo "Film " . $tytul . " został dodany do bazy";

mysqli_close($conn);
?>